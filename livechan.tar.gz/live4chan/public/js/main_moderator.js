function user_setup()
{
}

function moderator_setup()
{
}
